import { GoogleGenAI, Modality } from "@google/genai";
import { getGeminiAI } from "./gemini";

function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const narrateText = async (text: string, voice: 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr' = 'Kore') => {
  if (!text) return;

  try {
    const ai = getGeminiAI();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Narrate the following content clearly: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const audioBuffer = await decodeAudioData(decodeBase64(base64Audio), audioCtx, 24000, 1);
      
      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioCtx.destination);
      source.start();
    }
  } catch (error) {
    console.error("Narration error:", error);
  }
};

export const narrateProtocol = async (protocol: any) => {
  let text = `Protocolo: ${protocol.title}. `;
  
  if (protocol.instructions) {
    text += `Instruções: ${protocol.instructions}. `;
  }

  if (protocol.steps && protocol.steps.length > 0) {
    text += "Passos a seguir: ";
    protocol.steps.forEach((step: any, index: number) => {
      text += `Passo ${index + 1}: ${step.action}. ${step.detail}. `;
    });
  }

  if (protocol.prescriptions && protocol.prescriptions.length > 0) {
    text += "Medicamentos: ";
    protocol.prescriptions.forEach((item: any) => {
      text += `${item.name}, ${item.quantity}, ${item.dosage} por ${item.days} dias. `;
    });
  }

  if (protocol.exercises && protocol.exercises.length > 0) {
    text += "Exercícios: ";
    protocol.exercises.forEach((ex: string) => {
      text += `${ex}. `;
    });
  }

  await narrateText(text);
};
